import React from 'react';

// This component is deprecated and has been replaced by ParticleSystem.tsx
// Keeping it here to prevent import errors if referenced by mistake.
const HologramCore: React.FC = () => {
  return null;
};

export default HologramCore;