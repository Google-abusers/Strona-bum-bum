import React, { useRef, useMemo, useEffect, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { SimulationConfig, PhysicsMode } from '../types';

interface ParticleSystemProps {
  config: SimulationConfig;
}

const COUNT = 1600;

// Sub-component for the visual guide rings
const OrbitalRings = ({ visible, color }: { visible: boolean, color: string }) => {
  const groupRef = useRef<THREE.Group>(null);
  const [opacity, setOpacity] = useState(0);

  useFrame((state, delta) => {
    // Smooth fade in/out
    const targetOpacity = visible ? 0.3 : 0;
    setOpacity(prev => THREE.MathUtils.lerp(prev, targetOpacity, delta * 2));

    if (groupRef.current) {
      // Gyroscopic rotation effect
      groupRef.current.rotation.z += delta * 0.05;
      groupRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.1) * 0.15;
      groupRef.current.rotation.y = Math.cos(state.clock.elapsedTime * 0.15) * 0.15;
    }
  });

  if (opacity < 0.01) return null;

  return (
    <group ref={groupRef}>
      {/* Inner Ring */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[8, 0.02, 16, 100]} />
        <meshBasicMaterial color={color} transparent opacity={opacity} side={THREE.DoubleSide} />
      </mesh>
      {/* Middle Ring (Thicker) */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[15, 0.05, 16, 100]} />
        <meshBasicMaterial color={color} transparent opacity={opacity * 0.5} side={THREE.DoubleSide} />
      </mesh>
      {/* Outer Ring */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[25, 0.01, 16, 100]} />
        <meshBasicMaterial color={color} transparent opacity={opacity * 0.3} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
};

const ParticleSystem: React.FC<ParticleSystemProps> = ({ config }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const { viewport, mouse } = useThree();
  
  // Physics State stored in Float32Arrays for performance
  const positions = useMemo(() => new Float32Array(COUNT * 3), []);
  const velocities = useMemo(() => new Float32Array(COUNT * 3), []);
  
  // Temporary working vectors to avoid GC
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const mouse3 = useMemo(() => new THREE.Vector3(), []);
  const targetVec = useMemo(() => new THREE.Vector3(), []);

  // Initialize
  useEffect(() => {
    for (let i = 0; i < COUNT; i++) {
      const i3 = i * 3;
      // Spawn in a sphere
      const r = 10 + Math.random() * 10; // Start a bit wider
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(2 * Math.random() - 1);
      
      positions[i3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i3 + 2] = r * Math.cos(phi);
      
      // Initial velocity
      velocities[i3] = (Math.random() - 0.5) * 0.01;
      velocities[i3 + 1] = (Math.random() - 0.5) * 0.01;
      velocities[i3 + 2] = (Math.random() - 0.5) * 0.01;
    }
  }, []);

  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // Mouse interaction: Project mouse to 3D space (z=0 plane approximation)
    mouse3.set(mouse.x * viewport.width / 2, mouse.y * viewport.height / 2, 0);
    
    // Delta cap to prevent huge jumps
    const dt = Math.min(delta, 0.1) * config.speed; 

    const targetColor = new THREE.Color(config.color);

    // Physics Loop
    for (let i = 0; i < COUNT; i++) {
      const i3 = i * 3;
      
      // 1. Get Current State
      let x = positions[i3];
      let y = positions[i3 + 1];
      let z = positions[i3 + 2];
      
      let vx = velocities[i3];
      let vy = velocities[i3 + 1];
      let vz = velocities[i3 + 2];

      // 2. Apply Forces based on Mode
      
      // Force 1: Center Attraction (Gravity)
      const distToCenterSq = x*x + y*y + z*z;
      const distToCenter = Math.sqrt(distToCenterSq);
      
      // Default gravity pull
      let gravityStrength = -0.5 * config.gravity; 
      
      if (config.mode === PhysicsMode.EXPLOSION) {
        gravityStrength = 25.0; // Massive outward force
      } else if (config.mode === PhysicsMode.VORTEX) {
        gravityStrength = -5.0; // Strong suck
      } else if (config.mode === PhysicsMode.FLOAT) {
        gravityStrength = -0.05; // Very weak
      }

      // Normalize dir to center
      if (distToCenter > 0.01) {
         const dirX = x / distToCenter;
         const dirY = y / distToCenter;
         const dirZ = z / distToCenter;

         vx += dirX * gravityStrength * dt;
         vy += dirY * gravityStrength * dt;
         vz += dirZ * gravityStrength * dt;
      }

      // Force 2: Rotation/Curl (Orbit Logic)
      if (config.mode === PhysicsMode.ORBIT || config.mode === PhysicsMode.VORTEX) {
        // Tangential force to induce spin
        vx += z * 1.5 * dt;
        vz -= x * 1.5 * dt;
        
        // Slight flatten force (pull to Y=0 plane) for Saturn-ring effect
        if (config.mode === PhysicsMode.ORBIT) {
          vy -= y * 0.5 * dt;
        }
      }

      // Force 3: Mouse Interaction (Repulsor/Attractor)
      const dx = x - mouse3.x;
      const dy = y - mouse3.y;
      const dz = z - mouse3.z;
      const distToMouseSq = dx*dx + dy*dy + dz*dz;
      
      if (distToMouseSq < 25) {
         const force = 8.0 / (distToMouseSq + 0.1);
         vx += dx * force * dt; // Repel
         vy += dy * force * dt;
         vz += dz * force * dt;
      }

      // Force 4: Chaos/Jitter
      if (config.chaos > 0) {
        vx += (Math.random() - 0.5) * config.chaos * dt * 2;
        vy += (Math.random() - 0.5) * config.chaos * dt * 2;
        vz += (Math.random() - 0.5) * config.chaos * dt * 2;
      }

      // Force 5: Drag/Damping (Simulate medium)
      const drag = config.mode === PhysicsMode.EXPLOSION ? 0.99 : 0.97;
      vx *= drag;
      vy *= drag;
      vz *= drag;

      // 3. Update Positions
      x += vx;
      y += vy;
      z += vz;

      // Boundary Check (Reset if too far, unless exploding)
      if (config.mode !== PhysicsMode.EXPLOSION && (x*x+y*y+z*z) > 1200) {
         x = x * 0.05;
         y = y * 0.05;
         z = z * 0.05;
         vx *= 0.1; vy *= 0.1; vz *= 0.1;
      }

      // Store back
      positions[i3] = x;
      positions[i3 + 1] = y;
      positions[i3 + 2] = z;
      velocities[i3] = vx;
      velocities[i3 + 1] = vy;
      velocities[i3 + 2] = vz;

      // 4. Update Instance Matrix with Visual Stretching
      dummy.position.set(x, y, z);
      
      // WARP SPEED EFFECT:
      // Look at where we are going.
      // This aligns the geometry to the velocity vector.
      // We add the current position to velocity to get the "target" to look at.
      const speed = Math.sqrt(vx*vx + vy*vy + vz*vz);
      
      if (speed > 0.001) {
        dummy.lookAt(x + vx, y + vy, z + vz);
      }
      
      // Scale Z (forward axis) based on speed to create "streaks"
      // This simulates motion blur trails cheaply.
      const stretch = Math.min(Math.max(speed * 15, 1), 8); // Min 1, Max 8 length
      const thickness = Math.max(0.3 - (speed * 0.5), 0.05); // Thinner when fast
      
      dummy.scale.set(thickness, thickness, stretch);
      
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    }
    
    // Safely apply color
    if (meshRef.current.material) {
       const mat = meshRef.current.material as THREE.MeshStandardMaterial;
       if (mat.color) mat.color.lerp(targetColor, 0.1);
       if (mat.emissive) mat.emissive.lerp(targetColor, 0.1);
    }
    
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <>
      {/* Visual Helper Rings (Only visible in Orbit/Vortex modes) */}
      <OrbitalRings 
        visible={config.mode === PhysicsMode.ORBIT || config.mode === PhysicsMode.VORTEX} 
        color={config.color} 
      />

      {/* The Particle Swarm */}
      <instancedMesh ref={meshRef} args={[undefined, undefined, COUNT]}>
        {/* Cone Geometry works better for "darts/streaks" than tetrahedron when stretched */}
        <coneGeometry args={[0.2, 1, 4]} /> 
        <meshStandardMaterial 
          color={config.color} 
          toneMapped={false} 
          emissive={config.color}
          emissiveIntensity={2.5}
          roughness={0.2}
          metalness={0.9}
        />
      </instancedMesh>
    </>
  );
};

export default ParticleSystem;